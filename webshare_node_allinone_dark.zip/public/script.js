/**
 * All-in-one client script (dark UI)
 * - Requests server IP via /__whoami to display instructions and build ws url
 * - Uses WebSocket signaling on the same host to exchange SDP/ICE
 * - LAN-only: iceServers empty
 */

(async function(){
  const whoami = await fetch('/__whoami').then(r=>r.json()).catch(()=>({ip:location.hostname, port:location.port||8080}));
  const serverIp = whoami.ip || location.hostname;
  const serverPort = whoami.port || location.port || 8080;
  const WS_URL = (location.protocol === 'https:' ? 'wss' : 'ws') + '://' + serverIp + ':' + serverPort;
  console.log('Signaling WS URL:', WS_URL);

  // show server info
  const serverInfo = document.getElementById('server-info');
  serverInfo.textContent = `Signaling: ws://${serverIp}:${serverPort} • Abra este URL no celular: http://${serverIp}:${serverPort}`;

  // UI elements
  const tabShare = document.getElementById('tab-share');
  const tabView = document.getElementById('tab-view');
  const sharePanel = document.getElementById('share-panel');
  const viewPanel = document.getElementById('view-panel');

  const shareSessionInput = document.getElementById('share-session');
  const btnCreate = document.getElementById('btn-create');
  const btnShare = document.getElementById('btn-share');
  const btnStop = document.getElementById('btn-stop');
  const localVideo = document.getElementById('localVideo');

  const viewSessionInput = document.getElementById('view-session');
  const btnConnect = document.getElementById('btn-connect');
  const btnDisconnect = document.getElementById('btn-disconnect');
  const remoteVideo = document.getElementById('remoteVideo');

  // State
  let ws = null;
  let pc = null;
  let localStream = null;
  let currentSession = null;
  const configuration = { iceServers: [] }; // LAN only

  // Tabs
  tabShare.addEventListener('click', ()=>{ tabShare.classList.add('active'); tabView.classList.remove('active'); sharePanel.classList.add('visible'); viewPanel.classList.remove('visible'); });
  tabView.addEventListener('click', ()=>{ tabView.classList.add('active'); tabShare.classList.remove('active'); viewPanel.classList.add('visible'); sharePanel.classList.remove('visible'); });

  // Utility: generate simple uuid
  function genId(){
    return 's-' + ([1e7]+-1e3+-4e3+-8e3+-1e11).replace(/[018]/g, c =>
      (c ^ crypto.getRandomValues(new Uint8Array(1))[0] & 15 >> c / 4).toString(16)
    );
  }

  function ensureWS(session){
    if (ws && ws.readyState === WebSocket.OPEN && currentSession === session) return;
    if (ws) ws.close();
    ws = new WebSocket(WS_URL);
    ws.addEventListener('open', ()=> {
      console.log('ws open, joining', session);
      ws.send(JSON.stringify({ session, type: 'join' }));
    });
    ws.addEventListener('message', async (evt) => {
      const data = JSON.parse(evt.data);
      if (!data || data.session !== session) return;
      if (data.type === 'offer'){
        console.log('Received offer');
        if (!pc) await createPeer(false, session);
        await pc.setRemoteDescription(new RTCSessionDescription(data.sdp));
        const answer = await pc.createAnswer();
        await pc.setLocalDescription(answer);
        ws.send(JSON.stringify({ session, type: 'answer', sdp: pc.localDescription }));
      } else if (data.type === 'answer'){
        console.log('Received answer');
        await pc.setRemoteDescription(new RTCSessionDescription(data.sdp));
      } else if (data.type === 'ice' && data.candidate){
        try {
          await pc.addIceCandidate(data.candidate);
        } catch (e){
          console.warn('addIce failed', e);
        }
      }
    });
    ws.addEventListener('close', ()=> console.log('ws closed'));
    ws.addEventListener('error', (e)=> console.error('ws error', e));
    currentSession = session;
  }

  async function createPeer(isCaller, session){
    pc = new RTCPeerConnection(configuration);
    pc.ontrack = (evt) => {
      console.log('ontrack', evt);
      remoteVideo.srcObject = evt.streams[0];
    };
    pc.onicecandidate = (evt) => {
      if (evt.candidate && ws && ws.readyState === WebSocket.OPEN){
        ws.send(JSON.stringify({ session, type: 'ice', candidate: evt.candidate }));
      }
    };
    if (isCaller && localStream){
      for (const track of localStream.getTracks()){
        pc.addTrack(track, localStream);
      }
    }
    return pc;
  }

  btnCreate.addEventListener('click', ()=>{
    const id = genId();
    shareSessionInput.value = id;
    viewSessionInput.value = id;
  });

  btnShare.addEventListener('click', async ()=>{
    const sid = shareSessionInput.value || genId();
    shareSessionInput.value = sid;
    viewSessionInput.value = sid;

    // capture display
    try {
      localStream = await navigator.mediaDevices.getDisplayMedia({ video: true, audio: true });
    } catch (e){
      alert('Erro ao capturar a tela: ' + (e.message || e));
      console.error(e);
      return;
    }
    localVideo.srcObject = localStream;
    // setup ws and pc
    ensureWS(sid);
    await new Promise(res => setTimeout(res, 150)); // small wait for ws open
    await createPeer(true, sid);
    const offer = await pc.createOffer();
    await pc.setLocalDescription(offer);
    const sendWhenOpen = () => {
      if (ws && ws.readyState === WebSocket.OPEN){
        ws.send(JSON.stringify({ session: sid, type: 'offer', sdp: pc.localDescription }));
      } else {
        setTimeout(sendWhenOpen, 100);
      }
    };
    sendWhenOpen();
  });

  btnStop.addEventListener('click', ()=>{
    if (localStream) {
      localStream.getTracks().forEach(t=>t.stop());
      localStream = null;
    }
    if (pc){ pc.close(); pc = null; }
    if (ws){ ws.close(); ws = null; currentSession = null; }
    localVideo.srcObject = null;
  });

  btnConnect.addEventListener('click', async ()=>{
    const sid = viewSessionInput.value.trim();
    if (!sid) { alert('Cole um session ID'); return; }
    ensureWS(sid);
    await createPeer(false, sid);
    // viewer waits for offer; handled in ws.onmessage
  });

  btnDisconnect.addEventListener('click', ()=>{
    if (pc){ pc.close(); pc = null; }
    if (ws){ ws.close(); ws = null; currentSession = null; }
    remoteVideo.srcObject = null;
  });

})();
