# WebShare — All-in-one Node server (Dark UI)

Por: Gerado pelo assistente

## O que é
Servidor único que serve os arquivos estáticos e fornece um WebSocket de sinalização para WebRTC.
Feito para uso em **LAN**. Abra no PC e no celular via o IP do PC (automaticamente detectado).

## Como usar

1. Instale dependências:
```bash
cd webshare_node_allinone_dark
npm install
```

2. Inicie o servidor:
```bash
node server.js
```

3. No terminal você verá algo como:
```
Server listening on http://192.168.0.15:8080
Open this URL on your phone (same Wi-Fi):
  http://192.168.0.15:8080
```

4. Abra o endereço mostrado no navegador do seu celular (mesma rede).  
5. No PC: clique **Criar Sessão** → **Compartilhar Tela**.  
6. No celular: cole o mesmo Session ID em **Visualizar** → **Conectar**.

## Observações
- `getDisplayMedia` funciona apenas em páginas servidas por `http://localhost` ou `https` OR when accessed via IP from local server — mobile browsers allow it when served from the PC's IP on same LAN.
- Para áudio do sistema, comportamento varia por navegador/OS.
- Sem STUN/TURN: funciona em redes onde peers conseguem conexão direta.

