/**
 * All-in-one server:
 * - Serves static files from /public
 * - Hosts a WebSocket signaling server on the same HTTP server
 * - Detects local IPv4 address and injects SIGNALING_WS_URL into served index.html via a simple endpoint
 *
 * Usage:
 *   npm install
 *   node server.js
 *
 * Access from PC: http://<your-pc-ip>:8080
 * Access from phone (same Wi-Fi): http://<your-pc-ip>:8080
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');
const url = require('url');
const { WebSocketServer } = require('ws');

const PORT = process.env.PORT ? Number(process.env.PORT) : 8080;
const PUBLIC_DIR = path.join(__dirname, 'public');

function getLocalIPv4() {
  const nets = os.networkInterfaces();
  for (const name of Object.keys(nets)) {
    for (const net of nets[name]) {
      // Skip over non-ipv4 and internal (i.e. 127.0.0.1)
      if (net.family === 'IPv4' && !net.internal) {
        return net.address;
      }
    }
  }
  return '127.0.0.1';
}

const server = http.createServer((req, res) => {
  try {
    const parsed = url.parse(req.url, true);
    // endpoint to get local IP
    if (parsed.pathname === '/__whoami') {
      const ip = getLocalIPv4();
      res.writeHead(200, {'Content-Type':'application/json'});
      res.end(JSON.stringify({ ip, port: PORT }));
      return;
    }
    // serve static files
    let pathname = parsed.pathname;
    if (pathname === '/') pathname = '/index.html';
    const filePath = path.join(PUBLIC_DIR, pathname);
    if (fs.existsSync(filePath) && fs.statSync(filePath).isFile()) {
      const ext = path.extname(filePath).toLowerCase();
      const ct = {
        '.html':'text/html',
        '.js':'application/javascript',
        '.css':'text/css',
        '.json':'application/json',
        '.png':'image/png',
        '.jpg':'image/jpeg',
        '.svg':'image/svg+xml'
      }[ext] || 'application/octet-stream';
      res.writeHead(200, {'Content-Type': ct});
      fs.createReadStream(filePath).pipe(res);
      return;
    }
    // not found
    res.writeHead(404, {'Content-Type':'text/plain'});
    res.end('Not found');
  } catch (e) {
    console.error('Server error', e);
    res.writeHead(500);
    res.end('Server error');
  }
});

const wss = new WebSocketServer({ noServer: true });
const sessions = new Map(); // session -> Set(ws)

wss.on('connection', (ws) => {
  ws.sessionId = null;
  ws.on('message', (message) => {
    let data;
    try { data = JSON.parse(message.toString()); } catch(e) { console.warn('invalid JSON', e); return; }
    const session = data.session;
    if (!session) return;
    // join
    if (data.type === 'join') {
      ws.sessionId = session;
      if (!sessions.has(session)) sessions.set(session, new Set());
      sessions.get(session).add(ws);
      console.log(`WS joined session ${session} (count=${sessions.get(session).size})`);
      return;
    }
    // broadcast to others
    const set = sessions.get(session);
    if (!set) return;
    const text = JSON.stringify(data);
    for (const client of set) {
      if (client !== ws && client.readyState === client.OPEN) {
        client.send(text);
      }
    }
  });
  ws.on('close', () => {
    if (ws.sessionId) {
      const set = sessions.get(ws.sessionId);
      if (set) {
        set.delete(ws);
        if (set.size === 0) sessions.delete(ws.sessionId);
      }
    }
  });
});

server.on('upgrade', (request, socket, head) => {
  // handle websocket upgrade
  const { pathname } = url.parse(request.url);
  // accept all upgrades at root; we don't enforce path here
  wss.handleUpgrade(request, socket, head, (ws) => {
    wss.emit('connection', ws, request);
  });
});

server.listen(PORT, '0.0.0.0', () => {
  const ip = getLocalIPv4();
  console.log(`Server listening on http://${ip}:${PORT}`);
  console.log('Open this URL on your phone (same Wi-Fi):');
  console.log(`  http://${ip}:${PORT}`);
});
